using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GoutiClothing.Pages.About
{
    public class SiteMapModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
