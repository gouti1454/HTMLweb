using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GoutiClothing.Pages.About
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
