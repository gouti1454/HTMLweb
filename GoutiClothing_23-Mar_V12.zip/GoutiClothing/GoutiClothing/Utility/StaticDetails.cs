﻿namespace GoutiClothing.Utility
{
    public static class StaticDetails
    {
        //These are the roles used along with identity user
        public const string AdminRole = "Admin";
        public const string ManagerRole = "Manager";
        public const string CustomerRole = "Customer";
        public const string StaffRole = "Staff";
    }
}
